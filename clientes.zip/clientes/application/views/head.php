   <!--∆∆ head -->
	<div class="row app-dashboard-top-nav-bar">
		<div class="content">
			<div class="">
				<button data-toggle="app-dashboard-sidebar" class="menu-icon hide-for-medium"></button>
				<a class="app-dashboard-logo">
				<img src="<?php echo base_url();?>img/logo.png" alt="">
			</a>
			</div>
		</div>
	</div>