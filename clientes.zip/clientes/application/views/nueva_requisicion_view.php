<?php
require('header.php');
?>
	<body>	

	    <div class="app-dashboard shrink-medium">
        		<!--∆ head -->
		  <?php require('head.php'); ?>   

		 <!-- ∆∆ Body off canvas -->
		  <div class="app-dashboard-body off-canvas-wrapper">
			      
		      <!-- ∆menus -->	
		     <?php require('sidebar_menu.php'); ?>   

			<!--∆∆∆  content-->
			<div class="app-dashboard-body-content off-canvas-content" data-off-canvas-content>

				<h3 class="font2 colorFont light">Listado de Requisiciones</h3>

						<?php 
							if($this->session->flashdata('requisicion_valida'))
							{
						?>
						      <div class="warning2">
							<p ><?=$this->session->flashdata('requisicion_valida')?></p>
						</div>
						<?php
							}
							if($this->session->flashdata('requisicion_invalida'))
							{
						?>
							<p><?=$this->session->flashdata('requisicion_invalida')?></p>
						<?php
							}
						?>
						
						<div class="fol">						
							Folio : <?php echo $folio;?>
							Fecha : <?php echo date('Y-m-d');?>
						</div>
						<form name="fr-req" id="fr-req" action="<?php echo base_url().'Requisicion/guardar_requisicion'; ?>" method="post" accept-charset="utf-8" class="show-for-large">

							<div class="table-responsive">
							  <table class="table" id='tabla_req'>
							    <thead>
							      <tr>
							        <th>No</th>
							        <th>Artículo</th>
							        <th>Medida</th>
							        <th>Cantidad</th>
							        <th>Proyecto</th>
							        <th>Comentarios</th>						        						        
							      </tr>
							    </thead>
							    <tbody>			    	
					    			<tr id="tr-1" class='tr-number'>
					    				<td>
					    					1						    						
					    				</td>
					    				<td>
					    			
					    					<textarea name="articulo-1" placeholder='Artículo' class="art"></textarea>
					    				</td>
					    				<td>
					    					<!-- <input type="text" name="medida-1" class='art' placeholder='Medida*'> -->
					    					<textarea name="medida-1" placeholder='Medida' class="art"></textarea>
					    				</td>
					    				<td>
					    					<!-- <input type="text" name="cantidad-1" class='art' placeholder='Cantidad*'> -->
					    					<textarea name="cantidad-1"  placeholder='Cantidad' class="art"></textarea>
					    				</td>
					    				<td>
					    					<!-- <input type="text" name="proyecto-1" class='art' placeholder='Proyecto*'> -->
					    					<textarea name="proyecto-1"  placeholder='Proyecto' class="art"></textarea>
					    				</td>
					    				<td>
					    					<textarea name="comentarios-1" placeholder='Comentarios' class="art"></textarea>
					    				</td>
					    			</tr>
							    </tbody>
							  </table>		
							  </div>
							  <div class="add2 show-for-large">
								 <input type="hidden" name="limit" value="1" id='limit'>			
								<button type="button" id="add" >Agregar fila</button>
								<input type="submit" name="submit" value="Enviar" title="Enviar"  />
							</div>	
						</form>


					<form action="<?php echo base_url().'Requisicion/guardar_requisicion'; ?>" method="post" accept-charset="utf-8"  id='fr-req-mov' name='fr-req-mov'>
						<div id='wrapper_ul'>
						<ul class="pricing-table hide-for-large" id='ul-1'>
							  <li class="title bgFont ">1</li>
							  <li class="price"><input type="text" name="articulo-1" class='art' placeholder='Artículo*'></li>
							  <li class="description"><input type="text" name="medida-1" class='art' placeholder='Medida*'></li>
							  <li><input type="text" name="cantidad-1" class='art' placeholder='Cantidad*'></li>
							  <li><input type="text" name="proyecto-1" class='art' placeholder='Proyecto*'></li>
							  <li><textarea name="comentarios-1" placeholder='Comentarios'></textarea></li>
						</ul>
						</div>
						 <div class="add2 hide-for-large">
						<input type="hidden" name="limitmobil" value="1" id='limitmobil'>			
								<button type="button" id="addMobil" >Agregar fila</button>
								<input type="submit" name="submit" value="Enviar" title="Enviar"  />
						</div>	
					</form>

			</div>
		        <!--∆∆∆  content-->
		</div>
	    </div>
	<?php
require('footer.php');
?>