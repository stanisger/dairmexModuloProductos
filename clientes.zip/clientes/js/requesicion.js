$(document).ready(function(){
 	function inputFormulario(){
 		var elemt = 0;
 		$('.art').each(function ()
	    {
	        elemt++;
	    });

	    return elemt;	
 	}
 	

 	$("#fr-req").submit(function(e){
 		
 		
 		var bad = 0;

	    $('.art').each(function ()
	    {
	        if ($.trim(this.value) == ""){bad++;}
	    });

	    ele = inputFormulario();

	    if(ele === bad){
	    	e.preventDefault();
	    	alert('Ingrese la información de al menos 1 fila');
	    }else{
	    	return true;
	    }

	    
 	})
 	/*
 	jQuery.validator.addClassRules("art", {				  
	  minlength: 3
	});

	$("#fr-req").validate();
	
	$.validator.messages.required 	= "Campo obligatorio *";
	$.validator.messages.minlength  = "2 caracteres mínimo";
	*/
 	$("#add").click(function(){
 		var idlastsr = $('#tabla_req tr:last').attr('id');
 		var idrow 	 = idlastsr.split('tr-');
 		//alert(idrow[1]);
 		if(isNaN(parseInt(idrow[1]))===false){
 			var nuevoId = parseInt(idrow[1])+1;
 			$("#limit").val(nuevoId);			 			
 			$("#tabla_req").append('<tr id="tr-'+nuevoId+'" class="tr-number"><td>'+nuevoId+'</td><td><textarea  name="articulo-'+nuevoId+'" class="art" placeholder="Artículo"></textarea></td><td><textarea  name="medida-'+nuevoId+'" class="art" placeholder="Medida*"></textarea></td><td><textarea name="cantidad-'+nuevoId+'" class="art" placeholder="Cantidad*""></textarea></td><td><textarea name="proyecto-'+nuevoId+'" class="art" placeholder="Proyecto*"></textarea></td><td><textarea name="comentarios-'+nuevoId+'" placeholder="Comentarios"></textarea></td></tr>');
 		}else{
 			alert('No se puede agregar la fila, refresque su navegador');
 		}
 	});

 	$("#addMobil").click(function(){
 		
 		var idlastul= $('#wrapper_ul').children().last().attr('id');
 		var idrowul 	 = idlastul.split('ul-');
 		
 		if(isNaN(parseInt(idrowul[1]))===false){
 			var nuevoId = parseInt(idrowul[1])+1;
 			$("#limitmobil").val(nuevoId);			 			
 			$("#wrapper_ul").append('<ul class="pricing-table hide-for-large" id="ul-'+nuevoId+'"><li class="title bgFont ">'+nuevoId+'</li><li class="price"><input type="text" name="articulo-'+nuevoId+'" class="art" placeholder="Artículo*"></li><li class="description"><input type="text" name="medida-'+nuevoId+'" class="art" placeholder="Medida*"></li><li><input type="text" name="cantidad-'+nuevoId+'" class="art" placeholder="Cantidad*"></li><li><input type="text" name="proyecto-'+nuevoId+'" class="art" placeholder="Proyecto*"></li><li><textarea name="comentarios-'+nuevoId+'" placeholder="Comentarios"></textarea></li></ul>');
 		}else{
 			alert('No se puede agregar la fila, refresque su navegador');
 		}
 	});
 });